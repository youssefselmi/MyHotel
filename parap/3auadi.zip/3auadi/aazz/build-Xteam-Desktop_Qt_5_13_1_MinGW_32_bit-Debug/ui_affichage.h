/********************************************************************************
** Form generated from reading UI file 'affichage.ui'
**
** Created by: Qt User Interface Compiler version 5.13.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_AFFICHAGE_H
#define UI_AFFICHAGE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableView>

QT_BEGIN_NAMESPACE

class Ui_Affichage
{
public:
    QTableView *tabdemande;
    QPushButton *pushButton;
    QLineEdit *ref;
    QLineEdit *quantite;
    QLineEdit *type;
    QLineEdit *cin;
    QLineEdit *etat;
    QLineEdit *date;
    QPushButton *supprimer_demande;
    QPushButton *modifier_demande;
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;
    QComboBox *comboBox;
    QPushButton *recherche_demande;
    QLineEdit *lineEdit_recherche;
    QPushButton *pushButton_4;
    QPushButton *pushButton_5;
    QPushButton *pushButton_6;
    QPushButton *pushButton_7;
    QPushButton *pushButton_8;

    void setupUi(QDialog *Affichage)
    {
        if (Affichage->objectName().isEmpty())
            Affichage->setObjectName(QString::fromUtf8("Affichage"));
        Affichage->resize(1071, 469);
        tabdemande = new QTableView(Affichage);
        tabdemande->setObjectName(QString::fromUtf8("tabdemande"));
        tabdemande->setGeometry(QRect(10, 20, 631, 281));
        pushButton = new QPushButton(Affichage);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(690, 30, 75, 23));
        ref = new QLineEdit(Affichage);
        ref->setObjectName(QString::fromUtf8("ref"));
        ref->setGeometry(QRect(820, 30, 161, 20));
        quantite = new QLineEdit(Affichage);
        quantite->setObjectName(QString::fromUtf8("quantite"));
        quantite->setGeometry(QRect(820, 70, 161, 20));
        type = new QLineEdit(Affichage);
        type->setObjectName(QString::fromUtf8("type"));
        type->setGeometry(QRect(820, 110, 161, 20));
        cin = new QLineEdit(Affichage);
        cin->setObjectName(QString::fromUtf8("cin"));
        cin->setGeometry(QRect(820, 150, 161, 20));
        etat = new QLineEdit(Affichage);
        etat->setObjectName(QString::fromUtf8("etat"));
        etat->setGeometry(QRect(820, 190, 161, 20));
        date = new QLineEdit(Affichage);
        date->setObjectName(QString::fromUtf8("date"));
        date->setGeometry(QRect(820, 230, 161, 20));
        supprimer_demande = new QPushButton(Affichage);
        supprimer_demande->setObjectName(QString::fromUtf8("supprimer_demande"));
        supprimer_demande->setGeometry(QRect(810, 270, 75, 23));
        modifier_demande = new QPushButton(Affichage);
        modifier_demande->setObjectName(QString::fromUtf8("modifier_demande"));
        modifier_demande->setGeometry(QRect(900, 270, 75, 23));
        pushButton_2 = new QPushButton(Affichage);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(690, 60, 75, 23));
        pushButton_3 = new QPushButton(Affichage);
        pushButton_3->setObjectName(QString::fromUtf8("pushButton_3"));
        pushButton_3->setGeometry(QRect(690, 90, 75, 23));
        comboBox = new QComboBox(Affichage);
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->setObjectName(QString::fromUtf8("comboBox"));
        comboBox->setGeometry(QRect(10, 330, 62, 22));
        recherche_demande = new QPushButton(Affichage);
        recherche_demande->setObjectName(QString::fromUtf8("recherche_demande"));
        recherche_demande->setGeometry(QRect(200, 330, 75, 23));
        lineEdit_recherche = new QLineEdit(Affichage);
        lineEdit_recherche->setObjectName(QString::fromUtf8("lineEdit_recherche"));
        lineEdit_recherche->setGeometry(QRect(80, 330, 113, 20));
        pushButton_4 = new QPushButton(Affichage);
        pushButton_4->setObjectName(QString::fromUtf8("pushButton_4"));
        pushButton_4->setGeometry(QRect(900, 310, 75, 23));
        pushButton_5 = new QPushButton(Affichage);
        pushButton_5->setObjectName(QString::fromUtf8("pushButton_5"));
        pushButton_5->setGeometry(QRect(810, 310, 75, 23));
        pushButton_6 = new QPushButton(Affichage);
        pushButton_6->setObjectName(QString::fromUtf8("pushButton_6"));
        pushButton_6->setGeometry(QRect(690, 120, 75, 23));
        pushButton_7 = new QPushButton(Affichage);
        pushButton_7->setObjectName(QString::fromUtf8("pushButton_7"));
        pushButton_7->setGeometry(QRect(690, 150, 75, 23));
        pushButton_8 = new QPushButton(Affichage);
        pushButton_8->setObjectName(QString::fromUtf8("pushButton_8"));
        pushButton_8->setGeometry(QRect(690, 190, 75, 23));

        retranslateUi(Affichage);

        QMetaObject::connectSlotsByName(Affichage);
    } // setupUi

    void retranslateUi(QDialog *Affichage)
    {
        Affichage->setWindowTitle(QCoreApplication::translate("Affichage", "Dialog", nullptr));
        pushButton->setText(QCoreApplication::translate("Affichage", "affichage", nullptr));
        supprimer_demande->setText(QCoreApplication::translate("Affichage", "supprimer", nullptr));
        modifier_demande->setText(QCoreApplication::translate("Affichage", "modifier", nullptr));
        pushButton_2->setText(QCoreApplication::translate("Affichage", "Print", nullptr));
        pushButton_3->setText(QCoreApplication::translate("Affichage", "PDF", nullptr));
        comboBox->setItemText(0, QCoreApplication::translate("Affichage", "TYPE", nullptr));
        comboBox->setItemText(1, QCoreApplication::translate("Affichage", "ETAT", nullptr));
        comboBox->setItemText(2, QCoreApplication::translate("Affichage", "CIN", nullptr));

        recherche_demande->setText(QCoreApplication::translate("Affichage", "recherche", nullptr));
        pushButton_4->setText(QCoreApplication::translate("Affichage", "Accepter", nullptr));
        pushButton_5->setText(QCoreApplication::translate("Affichage", "Refuser", nullptr));
        pushButton_6->setText(QCoreApplication::translate("Affichage", "Trier etat", nullptr));
        pushButton_7->setText(QCoreApplication::translate("Affichage", "Trier CIN", nullptr));
        pushButton_8->setText(QCoreApplication::translate("Affichage", "stat", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Affichage: public Ui_Affichage {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_AFFICHAGE_H
