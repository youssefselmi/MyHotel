/********************************************************************************
** Form generated from reading UI file 'dialogmateriaux.ui'
**
** Created by: Qt User Interface Compiler version 5.13.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DIALOGMATERIAUX_H
#define UI_DIALOGMATERIAUX_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableView>

QT_BEGIN_NAMESPACE

class Ui_dialogMateriaux
{
public:
    QLineEdit *etatM_3;
    QLineEdit *rechercheM;
    QPushButton *pushButton_31;
    QLineEdit *idMS;
    QPushButton *pushButton_33;
    QPushButton *pushButton_18;
    QPushButton *pushButton_28;
    QComboBox *comboBox;
    QLineEdit *QNT_3;
    QTableView *tableView;
    QPushButton *pushButton;
    QLineEdit *Ref_3;
    QPushButton *pushButton_36;

    void setupUi(QDialog *dialogMateriaux)
    {
        if (dialogMateriaux->objectName().isEmpty())
            dialogMateriaux->setObjectName(QString::fromUtf8("dialogMateriaux"));
        dialogMateriaux->resize(813, 479);
        etatM_3 = new QLineEdit(dialogMateriaux);
        etatM_3->setObjectName(QString::fromUtf8("etatM_3"));
        etatM_3->setGeometry(QRect(30, 440, 160, 25));
        etatM_3->setAutoFillBackground(true);
        rechercheM = new QLineEdit(dialogMateriaux);
        rechercheM->setObjectName(QString::fromUtf8("rechercheM"));
        rechercheM->setGeometry(QRect(460, 150, 121, 25));
        rechercheM->setAutoFillBackground(true);
        pushButton_31 = new QPushButton(dialogMateriaux);
        pushButton_31->setObjectName(QString::fromUtf8("pushButton_31"));
        pushButton_31->setGeometry(QRect(240, 410, 80, 21));
        pushButton_31->setAutoFillBackground(true);
        idMS = new QLineEdit(dialogMateriaux);
        idMS->setObjectName(QString::fromUtf8("idMS"));
        idMS->setGeometry(QRect(460, 30, 113, 21));
        pushButton_33 = new QPushButton(dialogMateriaux);
        pushButton_33->setObjectName(QString::fromUtf8("pushButton_33"));
        pushButton_33->setGeometry(QRect(480, 120, 80, 21));
        pushButton_33->setAutoFillBackground(true);
        pushButton_18 = new QPushButton(dialogMateriaux);
        pushButton_18->setObjectName(QString::fromUtf8("pushButton_18"));
        pushButton_18->setGeometry(QRect(360, 410, 80, 21));
        pushButton_18->setAutoFillBackground(true);
        pushButton_28 = new QPushButton(dialogMateriaux);
        pushButton_28->setObjectName(QString::fromUtf8("pushButton_28"));
        pushButton_28->setGeometry(QRect(480, 90, 80, 21));
        pushButton_28->setAutoFillBackground(true);
        comboBox = new QComboBox(dialogMateriaux);
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->setObjectName(QString::fromUtf8("comboBox"));
        comboBox->setGeometry(QRect(480, 190, 72, 22));
        QNT_3 = new QLineEdit(dialogMateriaux);
        QNT_3->setObjectName(QString::fromUtf8("QNT_3"));
        QNT_3->setGeometry(QRect(30, 400, 160, 25));
        QNT_3->setAutoFillBackground(true);
        tableView = new QTableView(dialogMateriaux);
        tableView->setObjectName(QString::fromUtf8("tableView"));
        tableView->setGeometry(QRect(30, 20, 421, 281));
        pushButton = new QPushButton(dialogMateriaux);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(480, 60, 80, 21));
        Ref_3 = new QLineEdit(dialogMateriaux);
        Ref_3->setObjectName(QString::fromUtf8("Ref_3"));
        Ref_3->setGeometry(QRect(30, 360, 160, 25));
        Ref_3->setAutoFillBackground(true);
        pushButton_36 = new QPushButton(dialogMateriaux);
        pushButton_36->setObjectName(QString::fromUtf8("pushButton_36"));
        pushButton_36->setGeometry(QRect(460, 220, 101, 21));
        pushButton_36->setAutoFillBackground(true);

        retranslateUi(dialogMateriaux);

        QMetaObject::connectSlotsByName(dialogMateriaux);
    } // setupUi

    void retranslateUi(QDialog *dialogMateriaux)
    {
        dialogMateriaux->setWindowTitle(QCoreApplication::translate("dialogMateriaux", "Dialog", nullptr));
        pushButton_31->setText(QCoreApplication::translate("dialogMateriaux", "modifier", nullptr));
        pushButton_33->setText(QCoreApplication::translate("dialogMateriaux", "pdf", nullptr));
        pushButton_18->setText(QCoreApplication::translate("dialogMateriaux", "affichage", nullptr));
        pushButton_28->setText(QCoreApplication::translate("dialogMateriaux", "print", nullptr));
        comboBox->setItemText(0, QCoreApplication::translate("dialogMateriaux", "reference", nullptr));
        comboBox->setItemText(1, QCoreApplication::translate("dialogMateriaux", "nbr", nullptr));
        comboBox->setItemText(2, QCoreApplication::translate("dialogMateriaux", "etat", nullptr));

        pushButton->setText(QCoreApplication::translate("dialogMateriaux", "supprimer", nullptr));
        pushButton_36->setText(QCoreApplication::translate("dialogMateriaux", "recherche ", nullptr));
    } // retranslateUi

};

namespace Ui {
    class dialogMateriaux: public Ui_dialogMateriaux {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIALOGMATERIAUX_H
