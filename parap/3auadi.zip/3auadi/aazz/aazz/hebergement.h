#ifndef HEBERGEMENT_H
#define HEBERGEMENT_H

class hebergement
{
public:
    hebergement();
};

#endif // HEBERGEMENT_H
