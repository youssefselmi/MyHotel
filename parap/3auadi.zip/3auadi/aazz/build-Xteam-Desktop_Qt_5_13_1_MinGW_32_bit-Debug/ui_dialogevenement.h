/********************************************************************************
** Form generated from reading UI file 'dialogevenement.ui'
**
** Created by: Qt User Interface Compiler version 5.13.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DIALOGEVENEMENT_H
#define UI_DIALOGEVENEMENT_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCalendarWidget>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableView>

QT_BEGIN_NAMESPACE

class Ui_DialogEvenement
{
public:
    QLineEdit *idEVE_3;
    QPushButton *pushButton_29;
    QPushButton *pushButton_36;
    QPushButton *pushButton_30;
    QLineEdit *NBpEVE_3;
    QTableView *tableView_2;
    QComboBox *comboBox;
    QCalendarWidget *calendarWidget_8;
    QPushButton *pushButton_33;
    QPushButton *pushButton_3;
    QLineEdit *rechercheM_3;
    QPushButton *pushButton_21;
    QLineEdit *idES_2;
    QLineEdit *TypeEVE_3;

    void setupUi(QDialog *DialogEvenement)
    {
        if (DialogEvenement->objectName().isEmpty())
            DialogEvenement->setObjectName(QString::fromUtf8("DialogEvenement"));
        DialogEvenement->resize(808, 488);
        idEVE_3 = new QLineEdit(DialogEvenement);
        idEVE_3->setObjectName(QString::fromUtf8("idEVE_3"));
        idEVE_3->setGeometry(QRect(40, 340, 160, 25));
        idEVE_3->setAutoFillBackground(true);
        pushButton_29 = new QPushButton(DialogEvenement);
        pushButton_29->setObjectName(QString::fromUtf8("pushButton_29"));
        pushButton_29->setGeometry(QRect(510, 80, 80, 21));
        pushButton_29->setAutoFillBackground(true);
        pushButton_36 = new QPushButton(DialogEvenement);
        pushButton_36->setObjectName(QString::fromUtf8("pushButton_36"));
        pushButton_36->setGeometry(QRect(510, 170, 91, 21));
        pushButton_36->setAutoFillBackground(true);
        pushButton_30 = new QPushButton(DialogEvenement);
        pushButton_30->setObjectName(QString::fromUtf8("pushButton_30"));
        pushButton_30->setGeometry(QRect(510, 110, 80, 21));
        pushButton_30->setAutoFillBackground(true);
        NBpEVE_3 = new QLineEdit(DialogEvenement);
        NBpEVE_3->setObjectName(QString::fromUtf8("NBpEVE_3"));
        NBpEVE_3->setGeometry(QRect(40, 400, 160, 25));
        NBpEVE_3->setAutoFillBackground(true);
        tableView_2 = new QTableView(DialogEvenement);
        tableView_2->setObjectName(QString::fromUtf8("tableView_2"));
        tableView_2->setGeometry(QRect(10, 10, 481, 321));
        comboBox = new QComboBox(DialogEvenement);
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->setObjectName(QString::fromUtf8("comboBox"));
        comboBox->setGeometry(QRect(630, 140, 72, 22));
        calendarWidget_8 = new QCalendarWidget(DialogEvenement);
        calendarWidget_8->setObjectName(QString::fromUtf8("calendarWidget_8"));
        calendarWidget_8->setGeometry(QRect(300, 340, 131, 141));
        calendarWidget_8->setAutoFillBackground(true);
        pushButton_33 = new QPushButton(DialogEvenement);
        pushButton_33->setObjectName(QString::fromUtf8("pushButton_33"));
        pushButton_33->setGeometry(QRect(510, 430, 80, 21));
        pushButton_33->setAutoFillBackground(true);
        pushButton_3 = new QPushButton(DialogEvenement);
        pushButton_3->setObjectName(QString::fromUtf8("pushButton_3"));
        pushButton_3->setGeometry(QRect(510, 50, 80, 21));
        rechercheM_3 = new QLineEdit(DialogEvenement);
        rechercheM_3->setObjectName(QString::fromUtf8("rechercheM_3"));
        rechercheM_3->setGeometry(QRect(500, 140, 111, 25));
        rechercheM_3->setAutoFillBackground(true);
        pushButton_21 = new QPushButton(DialogEvenement);
        pushButton_21->setObjectName(QString::fromUtf8("pushButton_21"));
        pushButton_21->setGeometry(QRect(510, 400, 80, 21));
        pushButton_21->setAutoFillBackground(true);
        idES_2 = new QLineEdit(DialogEvenement);
        idES_2->setObjectName(QString::fromUtf8("idES_2"));
        idES_2->setGeometry(QRect(500, 20, 113, 21));
        TypeEVE_3 = new QLineEdit(DialogEvenement);
        TypeEVE_3->setObjectName(QString::fromUtf8("TypeEVE_3"));
        TypeEVE_3->setGeometry(QRect(40, 370, 160, 25));
        TypeEVE_3->setAutoFillBackground(true);

        retranslateUi(DialogEvenement);

        QMetaObject::connectSlotsByName(DialogEvenement);
    } // setupUi

    void retranslateUi(QDialog *DialogEvenement)
    {
        DialogEvenement->setWindowTitle(QCoreApplication::translate("DialogEvenement", "Dialog", nullptr));
        pushButton_29->setText(QCoreApplication::translate("DialogEvenement", "pdf", nullptr));
        pushButton_36->setText(QCoreApplication::translate("DialogEvenement", "recherche ", nullptr));
        pushButton_30->setText(QCoreApplication::translate("DialogEvenement", "print", nullptr));
        comboBox->setItemText(0, QCoreApplication::translate("DialogEvenement", "id", nullptr));
        comboBox->setItemText(1, QCoreApplication::translate("DialogEvenement", "type", nullptr));
        comboBox->setItemText(2, QCoreApplication::translate("DialogEvenement", "date", nullptr));
        comboBox->setItemText(3, QCoreApplication::translate("DialogEvenement", "nbr", nullptr));

        pushButton_33->setText(QCoreApplication::translate("DialogEvenement", "modifier", nullptr));
        pushButton_3->setText(QCoreApplication::translate("DialogEvenement", "supprimer", nullptr));
        pushButton_21->setText(QCoreApplication::translate("DialogEvenement", "affichage", nullptr));
    } // retranslateUi

};

namespace Ui {
    class DialogEvenement: public Ui_DialogEvenement {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIALOGEVENEMENT_H
